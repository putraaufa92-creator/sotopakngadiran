import Navbar from './components/Navbar'
import Hero from './components/Hero'
import About from './components/About'
import Signature from './components/Signature'
import Menu from './components/Menu'
import Story from './components/Story'
import Reviews from './components/Reviews'
import Experience from './components/Experience'
import Location from './components/Location'
import Footer from './components/Footer'

export default function App() {
  return (
    <div className="bg-cream text-choco">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Signature />
        <Menu />
        <Story />
        <Reviews />
        <Experience />
        <Location />
      </main>
      <Footer />
    </div>
  )
}
