import Reveal from './Reveal'
import RevealText from './RevealText'

const FEATURED = {
  quote:
    "Authentic taste, warm atmosphere, and a bowl that feels like Yogyakarta.",
  name: 'Customer Review',
}

const OTHERS = [
  {
    quote:
      'Kuahnya bening tapi rasanya dalam. Setiap suapan terasa jujur, tidak berlebihan.',
    name: 'Customer Review',
  },
  {
    quote:
      'Salah satu tempat yang selalu saya kunjungi setiap kembali ke Yogyakarta.',
    name: 'Customer Review',
  },
  {
    quote:
      'Sederhana namun berkarakter. Ini soto yang mengingatkan pada rumah.',
    name: 'Customer Review',
  },
]

export default function Reviews() {
  return (
    <section id="reviews" className="py-28 md:py-44 bg-cream">
      <div className="max-w-content mx-auto px-6 md:px-10">
        <RevealText
          lines={['What people say']}
          className="font-display text-4xl sm:text-5xl leading-[1.05] text-choco mb-16 md:mb-20"
        />

        <div className="grid md:grid-cols-12 gap-10 md:gap-8">
          {/* featured quote, large scale */}
          <Reveal className="md:col-span-7">
            <span className="font-display text-6xl md:text-7xl text-gold/60 leading-none block mb-4">
              "
            </span>
            <p className="font-display italic text-2xl sm:text-3xl text-choco leading-snug max-w-lg -mt-8 md:-mt-10">
              {FEATURED.quote}
            </p>
            <p className="text-[12px] tracking-[0.2em] uppercase text-coffee/70 mt-6">
              — {FEATURED.name}
            </p>
          </Reveal>

          {/* supporting quotes, stacked, quieter */}
          <div className="md:col-span-5 flex flex-col divide-y divide-choco/10 md:border-l md:border-choco/10 md:pl-8">
            {OTHERS.map((r, i) => (
              <Reveal key={i} delay={0.08 + i * 0.06} className="py-6 first:pt-0">
                <p className="text-choco/75 text-[15px] leading-relaxed mb-3">
                  "{r.quote}"
                </p>
                <p className="text-[11px] tracking-[0.18em] uppercase text-coffee/60">
                  — {r.name}
                </p>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
