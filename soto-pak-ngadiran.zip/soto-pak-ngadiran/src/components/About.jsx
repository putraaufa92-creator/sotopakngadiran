import Reveal from './Reveal'
import RevealText from './RevealText'
import RevealImage from './RevealImage'
import sotoHero from '../assets/soto-hero.png'

export default function About() {
  return (
    <section id="about" className="py-28 md:py-44 bg-cream">
      <div className="max-w-content mx-auto px-6 md:px-10 grid md:grid-cols-12 gap-12 md:gap-6 items-start">
        <div className="md:col-span-7 md:pr-10">
          <RevealText
            lines={['More than a bowl', 'of soto']}
            className="font-display text-4xl sm:text-5xl lg:text-6xl leading-[1.05] text-choco mb-10"
          />

          <div className="text-choco/80 text-[16px] leading-[1.85] max-w-md">
            <Reveal delay={0.05} y={16}>
              <p className="mb-6">
                <span className="font-display text-6xl leading-[0.7] float-left mr-3 mt-1 text-coffee">
                  D
                </span>
                i tengah riuhnya kuliner Yogyakarta, Soto Pak Ngadiran memilih
                jalan yang sederhana: menjaga rasa tetap seperti semula. Kuah
                bening, daging sapi yang dimasak dengan sabar, dan pelengkap
                yang dipilih tanpa tergesa.
              </p>
            </Reveal>
            <Reveal delay={0.1} y={16}>
              <p className="mb-6">
                Bertahun-tahun berjalan, warung ini tidak banyak berubah.
                Bukan karena enggan berkembang, tapi karena rasa yang dicari
                orang adalah rasa yang sama seperti dulu — hangat, jujur, dan
                mengingatkan pada rumah.
              </p>
            </Reveal>
            <Reveal delay={0.15} y={16}>
              <p>
                Bagi banyak orang Yogyakarta, semangkuk soto di sini bukan
                sekadar sarapan. Ia adalah bagian dari rutinitas, dari
                cerita, dari cara kota ini merayakan kesederhanaan.
              </p>
            </Reveal>
          </div>
        </div>

        <div className="md:col-span-5 md:pt-16">
          <RevealImage direction="up" className="relative aspect-[4/5] w-full max-w-sm mx-auto">
            <img
              src={sotoHero}
              alt="Detail mangkuk Soto Pak Ngadiran"
              className="w-full h-full object-cover"
              style={{ objectPosition: '30% 40%' }}
            />
          </RevealImage>
        </div>
      </div>
    </section>
  )
}
