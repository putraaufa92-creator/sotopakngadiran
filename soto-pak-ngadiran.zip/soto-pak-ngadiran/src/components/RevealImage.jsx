import { motion } from 'framer-motion'

const CLIPS = {
  up: ['inset(100% 0% 0% 0%)', 'inset(0% 0% 0% 0%)'],
  down: ['inset(0% 0% 100% 0%)', 'inset(0% 0% 0% 0%)'],
  left: ['inset(0% 100% 0% 0%)', 'inset(0% 0% 0% 0%)'],
  right: ['inset(0% 0% 0% 100%)', 'inset(0% 0% 0% 0%)'],
}

export default function RevealImage({
  children,
  className = '',
  direction = 'up',
  delay = 0,
  duration = 1.15,
}) {
  const [from, to] = CLIPS[direction]
  return (
    <motion.div
      initial={{ clipPath: from }}
      whileInView={{ clipPath: to }}
      viewport={{ once: true, margin: '-100px' }}
      transition={{ duration, delay, ease: [0.65, 0, 0.35, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  )
}
