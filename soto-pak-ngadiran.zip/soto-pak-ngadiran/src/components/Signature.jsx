import Reveal from './Reveal'
import RevealText from './RevealText'
import RevealImage from './RevealImage'
import Grain from './Grain'
import sotoHero from '../assets/soto-hero.png'

const TRAITS = ['Authentic', 'Traditional', 'Yogyakarta']

export default function Signature() {
  return (
    <section className="py-28 md:py-44 bg-beige/40">
      <div className="max-w-content mx-auto px-6 md:px-10">
        <div className="grid md:grid-cols-12 gap-12 md:gap-6 items-center">
          <div className="md:col-span-6 relative order-1">
            <RevealImage
              direction="right"
              className="relative w-full aspect-[6/5] max-w-xl overflow-hidden shadow-[0_35px_70px_-20px_rgba(53,34,24,0.4)]"
            >
              <img
                src={sotoHero}
                alt="Soto Pak Ngadiran dengan kuah bening dan daging sapi"
                className="w-full h-full object-cover"
              />
              <Grain opacity={0.06} />
            </RevealImage>
          </div>

          <div className="md:col-span-6 order-2 md:pl-10">
            <RevealText
              lines={['A bowl that speaks', 'for itself']}
              className="font-display text-4xl sm:text-5xl leading-[1.05] text-choco mb-8"
            />
            <Reveal delay={0.1}>
              <p className="text-choco/80 text-[16px] leading-[1.85] max-w-md mb-10">
                Soto Pak Ngadiran dikenal dengan kuah bening yang gurih,
                potongan daging sapi yang lembut, serta perpaduan tauge, kol,
                daun seledri, dan pelengkap yang membuat setiap mangkuk
                terasa hangat dan sederhana.
              </p>
            </Reveal>
            <Reveal delay={0.15}>
              <div className="flex flex-wrap items-center gap-0 divide-x divide-choco/20">
                {TRAITS.map((trait) => (
                  <span
                    key={trait}
                    className="text-[13px] tracking-[0.18em] uppercase text-choco/80 px-6 first:pl-0"
                  >
                    {trait}
                  </span>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  )
}
