const LINK_GROUPS = [
  {
    title: 'Explore',
    links: [
      { label: 'About', href: '#about' },
      { label: 'Menu', href: '#menu' },
      { label: 'Reviews', href: '#reviews' },
      { label: 'Location', href: '#visit' },
    ],
  },
  {
    title: 'Social Media',
    links: [
      { label: 'Instagram', href: '#' },
      { label: 'TikTok', href: '#' },
      { label: 'WhatsApp', href: '#' },
    ],
  },
]

export default function Footer() {
  const handleNavigate = (e, href) => {
    if (href.startsWith('#') && href !== '#') {
      e.preventDefault()
      document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <footer className="bg-choco text-cream pt-20 pb-10">
      <div className="max-w-content mx-auto px-6 md:px-10">
        <div className="grid md:grid-cols-12 gap-10 mb-16">
          <div className="md:col-span-6">
            <p className="font-display text-2xl tracking-[0.2em] mb-6">
              SOTO PAK NGADIRAN
            </p>
            <p className="font-display italic text-lg text-cream/70 leading-relaxed max-w-xs">
              Rasa yang Sederhana,
              <br />
              Cerita yang Tak Lekang Waktu.
            </p>
          </div>

          <div className="md:col-span-6 grid grid-cols-2 gap-8">
            {LINK_GROUPS.map((group) => (
              <div key={group.title}>
                <p className="text-[11px] tracking-[0.2em] uppercase text-gold mb-5">
                  {group.title}
                </p>
                <ul className="space-y-3">
                  {group.links.map((link) => (
                    <li key={link.label}>
                      <a
                        href={link.href}
                        onClick={(e) => handleNavigate(e, link.href)}
                        className="text-cream/70 text-sm hover:text-cream transition-colors duration-300"
                      >
                        {link.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="border-t border-cream/15 pt-8 flex flex-col sm:flex-row justify-between gap-3 text-cream/50 text-xs">
          <p>© {new Date().getFullYear()} Soto Pak Ngadiran. All rights reserved.</p>
          <p>Yogyakarta, Indonesia</p>
        </div>
      </div>
    </footer>
  )
}
