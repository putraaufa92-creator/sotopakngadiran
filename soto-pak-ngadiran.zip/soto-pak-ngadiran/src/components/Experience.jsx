import { useRef } from 'react'
import { motion, useScroll, useTransform } from 'framer-motion'
import RevealText from './RevealText'
import Grain from './Grain'
import sotoHero from '../assets/soto-hero.png'

export default function Experience() {
  const ref = useRef(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start'],
  })

  const y = useTransform(scrollYProgress, [0, 1], ['-8%', '8%'])

  return (
    <section ref={ref} className="relative py-32 md:py-0 md:h-[85vh] bg-choco overflow-hidden">
      <div className="md:absolute md:inset-0 grid md:grid-cols-2 items-center">
        <div className="relative z-10 px-6 md:px-14 lg:px-20 mb-12 md:mb-0">
          <RevealText
            lines={['A simple bowl.', 'A timeless taste.']}
            className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-[4.2rem] leading-[1.05] text-cream"
          />
        </div>

        <div className="relative h-[60vh] md:h-full overflow-hidden">
          <motion.img
            style={{ y }}
            src={sotoHero}
            alt="Soto Pak Ngadiran disajikan hangat"
            className="w-full h-[120%] object-cover"
          />
          <div
            aria-hidden="true"
            className="absolute inset-0 hidden md:block"
            style={{
              background:
                'linear-gradient(90deg, rgba(53,34,24,0.9) 0%, rgba(53,34,24,0) 18%)',
            }}
          />
          <Grain opacity={0.06} />
        </div>
      </div>
    </section>
  )
}
