import { motion } from 'framer-motion'

/**
 * Reveals each line of text with a vertical mask wipe, magazine-style.
 * Pass `lines` as an array of strings, one per visual line.
 */
export default function RevealText({
  lines,
  as: Tag = 'h2',
  className = '',
  delay = 0,
  stagger = 0.09,
  once = true,
}) {
  return (
    <Tag className={className}>
      {lines.map((line, i) => (
        <span key={i} className="block overflow-hidden">
          <motion.span
            className="block"
            initial={{ y: '105%' }}
            whileInView={{ y: '0%' }}
            viewport={{ once, margin: '-100px' }}
            transition={{
              duration: 0.95,
              delay: delay + i * stagger,
              ease: [0.22, 1, 0.36, 1],
            }}
          >
            {line}
          </motion.span>
        </span>
      ))}
    </Tag>
  )
}
