import Reveal from './Reveal'
import RevealText from './RevealText'
import EditorialLink from './EditorialLink'

// TODO: ganti placeholder di bawah ini dengan alamat, jam buka,
// dan link Google Maps yang sebenarnya.
const ADDRESS = 'Jl. Contoh Alamat No. 00, Yogyakarta, Indonesia'
const HOURS = ['Senin – Sabtu: 06.00 – 14.00', 'Minggu: Tutup']
const MAPS_URL = 'https://maps.google.com/?q=Soto+Pak+Ngadiran+Yogyakarta'

export default function Location() {
  return (
    <section id="visit" className="py-28 md:py-44 bg-cream">
      <div className="max-w-content mx-auto px-6 md:px-10 grid md:grid-cols-12 gap-10 md:gap-6">
        <div className="md:col-span-5">
          <RevealText
            lines={['Visit Soto', 'Pak Ngadiran']}
            className="font-display text-4xl sm:text-5xl leading-[1.05] text-choco"
          />
          <Reveal delay={0.1}>
            <p className="font-display italic text-xl text-coffee mt-6">
              Yogyakarta, Indonesia
            </p>
          </Reveal>
        </div>

        <div className="md:col-span-7">
          <Reveal delay={0.15}>
            <div className="border-t border-choco/15 py-6 grid grid-cols-[7rem_1fr] sm:grid-cols-[9rem_1fr]">
              <p className="text-[11px] tracking-[0.18em] uppercase text-coffee/70">
                Location
              </p>
              <p className="text-choco/80 text-[15px]">{ADDRESS}</p>
            </div>
          </Reveal>

          <Reveal delay={0.2}>
            <div className="border-t border-choco/15 py-6 grid grid-cols-[7rem_1fr] sm:grid-cols-[9rem_1fr]">
              <p className="text-[11px] tracking-[0.18em] uppercase text-coffee/70">
                Hours
              </p>
              <div>
                {HOURS.map((h) => (
                  <p key={h} className="text-choco/80 text-[15px]">
                    {h}
                  </p>
                ))}
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.25}>
            <div className="border-t border-b border-choco/15 py-8">
              <EditorialLink href={MAPS_URL}>Open in Google Maps</EditorialLink>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
