import { motion } from 'framer-motion'
import RevealText from './RevealText'
import Reveal from './Reveal'

const MENU_ITEMS = [
  {
    name: 'Soto Daging Sapi',
    desc: 'Soto dengan kuah bening gurih dan potongan daging sapi.',
  },
  {
    name: 'Mendoan',
    desc: 'Tempe goreng hangat sebagai pendamping.',
  },
  {
    name: 'Babat',
    desc: 'Pelengkap untuk pencinta jeroan sapi.',
  },
  {
    name: 'Iso',
    desc: 'Pilihan pelengkap dengan karakter rasa yang khas.',
  },
  {
    name: 'Sambal',
    desc: 'Pelengkap pedas untuk memperkuat cita rasa.',
  },
  {
    name: 'Jeruk Nipis & Kecap',
    desc: 'Pelengkap untuk menyesuaikan rasa sesuai selera.',
  },
]

export default function Menu() {
  return (
    <section id="menu" className="py-28 md:py-44 bg-cream">
      <div className="max-w-content mx-auto px-6 md:px-10">
        <RevealText
          lines={['The menu']}
          className="font-display text-4xl sm:text-5xl leading-[1.05] text-choco mb-16 md:mb-24"
        />

        <div>
          {MENU_ITEMS.map((item, i) => (
            <Reveal key={item.name} delay={i * 0.04} y={14}>
              <motion.div
                whileHover="hover"
                className="group relative border-t border-choco/15 last:border-b py-7 md:py-8"
              >
                <motion.div
                  variants={{ hover: { opacity: 1 } }}
                  initial={{ opacity: 0 }}
                  transition={{ duration: 0.4 }}
                  className="absolute inset-0 bg-beige/30 -z-10"
                />
                <div className="grid grid-cols-[2.5rem_1fr] md:grid-cols-[3rem_1fr_2fr] items-baseline gap-x-4 px-2">
                  <span className="text-[13px] tabular-nums text-coffee/60">
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  <motion.h3
                    variants={{ hover: { x: 6 } }}
                    transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                    className="font-display text-2xl md:text-[1.75rem] text-choco"
                  >
                    {item.name}
                  </motion.h3>
                  <p className="col-span-2 md:col-span-1 text-choco/65 text-sm leading-relaxed mt-1 md:mt-0 md:text-right">
                    {item.desc}
                  </p>
                </div>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
