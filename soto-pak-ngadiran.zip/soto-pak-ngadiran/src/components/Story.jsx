import Reveal from './Reveal'
import RevealText from './RevealText'

const CHAPTERS = [
  {
    num: '01',
    title: 'The Beginning',
    text: 'Berawal dari sebuah gerobak kecil di sudut jalan Yogyakarta, dengan resep yang dijaga sepenuh hati.',
  },
  {
    num: '02',
    title: 'The Journey',
    text: 'Dari pelanggan ke pelanggan, cerita tentang mangkuk soto yang hangat ini terus berpindah tangan.',
  },
  {
    num: '03',
    title: 'The Taste',
    text: 'Racikan bumbu dan kuah tetap dijaga konsisten, karena rasa yang berubah berarti mengkhianati kepercayaan.',
  },
  {
    num: '04',
    title: 'Today',
    text: 'Kini, Soto Pak Ngadiran menjadi bagian dari perjalanan kuliner banyak orang yang datang ke Yogyakarta.',
  },
]

export default function Story() {
  return (
    <section id="story" className="py-28 md:py-40 bg-cream">
      <div className="max-w-content mx-auto px-6 md:px-10">
        <div className="max-w-xl mb-16 md:mb-24">
          <RevealText
            lines={['A story served', 'for generations']}
            className="font-display text-4xl sm:text-5xl leading-[1.05] text-choco"
          />
        </div>

        <div className="space-y-0">
          {CHAPTERS.map((chapter, i) => (
            <Reveal key={chapter.num} delay={i * 0.08}>
              <div
                className={`grid md:grid-cols-12 gap-4 md:gap-8 py-10 items-start ${
                  i !== 0 ? 'border-t border-choco/15' : ''
                }`}
              >
                <div className="md:col-span-2 flex items-baseline gap-3">
                  <span className="w-1.5 h-1.5 rounded-full bg-gold hidden md:inline-block" />
                  <span className="font-display text-4xl md:text-5xl text-choco/25">
                    {chapter.num}
                  </span>
                </div>
                <div className="md:col-span-3">
                  <h3 className="font-display text-2xl md:text-3xl text-choco">
                    {chapter.title}
                  </h3>
                </div>
                <div className="md:col-span-7">
                  <p className="text-choco/75 text-[15px] leading-relaxed max-w-md">
                    {chapter.text}
                  </p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
