import { useRef } from 'react'
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion'
import sotoHero from '../assets/soto-hero.png'
import RevealText from './RevealText'
import EditorialLink from './EditorialLink'
import Grain from './Grain'

export default function Hero() {
  const wrapRef = useRef(null)

  const px = useMotionValue(0)
  const py = useMotionValue(0)

  const spring = { stiffness: 50, damping: 16, mass: 0.7 }
  const sx = useSpring(px, spring)
  const sy = useSpring(py, spring)

  // image itself drifts opposite-light to the cursor — deep, slow parallax
  const imgX = useTransform(sx, [-0.5, 0.5], [-26, 26])
  const imgY = useTransform(sy, [-0.5, 0.5], [-20, 20])
  const imgScale = useTransform(
    [sx, sy],
    ([x, y]) => 1.08 + (Math.abs(x) + Math.abs(y)) * 0.02
  )

  // a slower background layer for depth (parallax within parallax)
  const bgX = useTransform(sx, [-0.5, 0.5], [-8, 8])
  const bgY = useTransform(sy, [-0.5, 0.5], [-6, 6])

  const handlePointerMove = (e) => {
    const rect = wrapRef.current.getBoundingClientRect()
    px.set((e.clientX - rect.left) / rect.width - 0.5)
    py.set((e.clientY - rect.top) / rect.height - 0.5)
  }
  const handlePointerLeave = () => {
    px.set(0)
    py.set(0)
  }

  return (
    <section
      id="home"
      className="relative min-h-[100svh] flex flex-col overflow-hidden bg-cream"
    >
      {/* vertical masthead label, far left — a single quiet structural device */}
      <div className="hidden lg:flex absolute left-6 top-0 bottom-0 items-center z-20">
        <span
          className="text-[11px] tracking-[0.4em] uppercase text-choco/60"
          style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}
        >
          Yogyakarta, Indonesia — Est. Warung Tradisional
        </span>
      </div>

      <div className="flex-1 grid lg:grid-cols-[1.05fr_1fr] pt-28 lg:pt-0">
        {/* Left: copy, vertically centered */}
        <div className="relative z-10 flex items-center px-6 sm:px-10 lg:pl-20 lg:pr-8 pb-12 lg:pb-0">
          <div className="max-w-lg">
            <RevealText
              as="h1"
              lines={['Soto', 'Pak Ngadiran']}
              className="font-display text-[3.4rem] sm:text-7xl lg:text-[5.75rem] leading-[0.92] text-choco"
              delay={0.15}
            />

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.75 }}
              className="font-display italic text-xl md:text-[1.7rem] text-coffee mt-7"
            >
              A taste of Yogyakarta's heritage
            </motion.p>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.9 }}
              className="text-choco/70 text-[15px] leading-relaxed mt-6 max-w-sm"
            >
              Semangkuk soto dengan cita rasa yang sederhana, hangat, dan
              telah menjadi bagian dari perjalanan kuliner Yogyakarta.
            </motion.p>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 1.05 }}
              className="mt-11"
            >
              <EditorialLink
                href="#about"
                onClick={(e) => {
                  e.preventDefault()
                  document.querySelector('#about')?.scrollIntoView({ behavior: 'smooth' })
                }}
              >
                Discover our story
              </EditorialLink>
            </motion.div>
          </div>
        </div>

        {/* Right: full-bleed interactive photograph */}
        <motion.div
          initial={{ clipPath: 'inset(0% 0% 0% 100%)' }}
          animate={{ clipPath: 'inset(0% 0% 0% 0%)' }}
          transition={{ duration: 1.3, ease: [0.65, 0, 0.35, 1] }}
          className="relative min-h-[46vh] lg:min-h-0"
        >
          <div
            ref={wrapRef}
            onPointerMove={handlePointerMove}
            onPointerLeave={handlePointerLeave}
            className="absolute inset-0 overflow-hidden"
          >
            {/* soft ambient background tone, drifts slower than the photo */}
            <motion.div
              aria-hidden="true"
              style={{ x: bgX, y: bgY }}
              className="absolute -inset-10 bg-gradient-to-br from-beige/60 via-transparent to-choco/10"
            />

            <motion.img
              style={{ x: imgX, y: imgY, scale: imgScale }}
              src={sotoHero}
              alt="Semangkuk Soto Pak Ngadiran dengan daging sapi, tauge, dan pelengkap segar, difoto dari atas"
              className="absolute inset-0 w-full h-full object-cover select-none"
              draggable={false}
            />

            {/* warm photographic grade, ties the image to the palette */}
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0"
              style={{
                background:
                  'linear-gradient(180deg, rgba(53,34,24,0.15) 0%, rgba(53,34,24,0) 30%, rgba(53,34,24,0) 70%, rgba(53,34,24,0.35) 100%)',
              }}
            />
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 lg:bg-gradient-to-r lg:from-cream/90 lg:via-cream/0 lg:to-transparent lg:w-1/4"
            />
            <Grain opacity={0.05} />
          </div>
        </motion.div>
      </div>

      {/* single hairline, the one deliberate gold moment in the hero */}
      <div className="hidden lg:block absolute left-0 right-0 bottom-0 h-px bg-gold/40" />
    </section>
  )
}
