export default function EditorialLink({
  href,
  onClick,
  children,
  className = '',
  dark = false,
}) {
  const base = dark ? 'text-cream' : 'text-choco'
  const line = dark ? 'bg-cream' : 'bg-choco'
  return (
    <a
      href={href}
      onClick={onClick}
      target={href?.startsWith('http') ? '_blank' : undefined}
      rel={href?.startsWith('http') ? 'noopener noreferrer' : undefined}
      className={`group relative inline-block text-[13px] tracking-[0.2em] uppercase ${base} pb-[6px] ${className}`}
    >
      {children}
      <span className="absolute left-0 bottom-0 h-px w-full bg-gold/50" />
      <span
        className={`absolute left-0 bottom-0 h-px w-0 ${line} transition-all duration-500 ease-out group-hover:w-full`}
      />
    </a>
  )
}
