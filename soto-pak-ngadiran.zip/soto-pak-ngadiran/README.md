# Soto Pak Ngadiran — Website

Website profil premium untuk Soto Pak Ngadiran, Yogyakarta.
Dibuat dengan React + Vite + Tailwind CSS + Framer Motion.

## Menjalankan di komputer kamu

Pastikan sudah install [Node.js](https://nodejs.org) (versi 18 ke atas), lalu:

```bash
npm install
npm run dev
```

Buka `http://localhost:5173` di browser.

## Build untuk production (upload ke hosting)

```bash
npm run build
```

Hasilnya ada di folder `dist/` — folder ini yang di-upload ke hosting
(Vercel, Netlify, atau hosting statis lainnya).

## Struktur komponen

```
src/
  components/
    Navbar.jsx      → navigasi, berubah warna saat scroll
    Hero.jsx         → hero section dengan foto interaktif (parallax)
    About.jsx        → cerita singkat brand
    Signature.jsx     → highlight menu andalan
    Menu.jsx          → daftar menu
    Story.jsx         → timeline perjalanan brand
    Reviews.jsx       → testimoni pelanggan
    Experience.jsx    → visual break dengan background gelap
    Location.jsx      → info lokasi & jam buka
    Footer.jsx        → footer
    Reveal.jsx        → wrapper animasi fade-up, dipakai berulang
  App.jsx             → menyusun semua section
  index.css           → base style, font, scrollbar
```

## Yang perlu kamu ganti sebelum publish

1. **Alamat, jam buka, dan link Google Maps** — ada di
   `src/components/Location.jsx`, ditandai komentar `TODO`.
2. **Link social media** — ada di `src/components/Footer.jsx`
   (masih placeholder `#`, ganti dengan link asli Instagram/TikTok/WhatsApp).
3. **Foto** — saat ini semua section memakai satu foto yang sama
   (`src/assets/soto-hero.png`). Kalau ada foto lain (interior warung,
   proses masak, dll), tinggal ganti/tambahkan di `src/assets/` dan
   import di komponen terkait.
4. **Testimoni** — testimoni di `src/components/Reviews.jsx` masih
   berupa placeholder yang realistis. Ganti dengan ulasan pelanggan asli
   begitu tersedia.

## Interaksi foto di Hero

- **Desktop**: foto mengikuti pergerakan cursor dengan efek parallax
  halus (pakai `onPointerMove`, jadi otomatis juga bekerja untuk stylus).
- **Mobile/tablet**: event pointer yang sama juga menangkap sentuhan jari
  tanpa mengganggu scroll halaman (area sentuh dibatasi ke gambar saja).
