/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        cream: '#F4EBDD',
        beige: '#E6D2B5',
        choco: '#352218',
        coffee: '#684633',
        gold: '#B49763',
      },
      fontFamily: {
        display: ['"Cormorant Garamond"', 'serif'],
        body: ['Inter', 'sans-serif'],
      },
      letterSpacing: {
        widest2: '0.35em',
      },
      maxWidth: {
        content: '1400px',
      },
    },
  },
  plugins: [],
}
